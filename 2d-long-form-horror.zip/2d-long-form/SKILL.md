---
name: 2d-long-form
description: "Make long-form horror / mystery (kịch dị, tâm linh, truyện ma, vụ án bí ẩn) animated YouTube videos, 3/5/10/15 min, in the dark stick-figure style of top Vietnamese horror narration channels: round white-headed ink puppets over many AI-painted foggy dark backgrounds, a fiction-disclaimer banner, channel badge, hard subtitles synced to the voice, paw-print navy strips, dread music and scare SFX. The agent running this skill designs and generates every background picture itself at runtime with its own image tool — the more AI backgrounds per video the better; drawn code rooms are only a last-resort fallback. Flow: pick market (Vietnamese recommended) → pitch 10 horror ideas → pick length → write script → user sends voiceover → finished 1080p MP4. Markets: Vietnamese, English, French, German; the conversation stays in Vietnamese."
---

# Horror Long Form (2D Stick-Figure)
Turns a horror topic into a finished, fully animated 16:9 video in five steps: **market → ideas → length → script → voiceover → MP4**. The look: flat ink round-head puppets (white round heads, thick black outline, simple coloured bodies, sweat/shock/terror faces) standing in **AI-painted dark horror backgrounds** — one painted world per place, era and hour, with wide/close/angle variants and night/dusk variants, generated per video so every story has its own gloomy world. A slow-pushing camera, dread music bed and scare sound effects under the user's untouched voice. Every frame carries the broadcast identity: a fiction-disclaimer banner top-left, the channel badge top-right, hard subtitles on a black band near the bottom, navy paw-print strips, and a small watermark.

Characters, graphics and motion are drawn with code (skia-python + ffmpeg); **the pictures come from an AI image source the agent operates itself** (see 4.1b). You don't write drawing code for pictures: you write a `story.json` storyboard (shot kinds + fields, a `backgrounds` block of image prompts, a `frame` identity block) and the engine aligns it to the voiceover word by word and renders it.

## Hard rules
- **Always talk to the user in Vietnamese** (every reply, question, idea list, progress note and delivery line). Address the user as "anh" and yourself as "em".
- **Market language decides on-screen content, not the conversation.** Spoken script, subtitles, labels, chapter cards and the speech model follow the chosen market (`vi`, `en`, `fr` or `de`). Conversation stays Vietnamese. Vietnamese (`vi`) is the default for this horror niche.
- **Original characters and branding only.** Copy the *visual language* (dark painted backgrounds, round-head puppets, disclaimer banner, subtitles), never another channel's name, logo, character designs, thumbnails or videos shot for shot. Default channel text is a placeholder; the user supplies their own channel name. Real people are generic puppets with a name tag, never a likeness.
- **Fiction safety (horror-specific).** Every video keeps the fiction disclaimer banner on screen. Stories are openly hư cấu; do not present rituals, curses or ghosts as instructions to perform; show no graphic gore, no real victim names, no real unsolved-crime details that could identify people; supernatural beats are framed as "truyền thuyết / lời đồn / điều kỳ lạ"; end with a cautionary or reassuring line when the story describes dangerous behaviour.
- **AI backgrounds are mandatory — and the more the better.** You (the agent) design and generate all pictures at runtime with your image tool; no pictures ship inside the skill. Design a rich set: one main picture per place × hour, plus close-ups, side angles and weather/light variants, plus soft backdrops for graphics shots (counts in 4.1b). Generate them proactively, in parallel, right after the script is written — do not wait for the voiceover. Reject and regenerate any picture with people, faces, readable text, watermarks, a bright cheerful style, or no open floor.
- **Drawn code rooms are a last-resort fallback only.** `engine/sets.py` keeps a dark abandoned-corridor set (`horror`) for the rare picture that could not be made. Never choose a code set on purpose, and never leave a world shot on a code set when an AI picture could be generated for it.
- **AI background prompts:** places only, never people/characters, faces, animals, brands, logos, readable text or a named artist/film/channel style. 2D illustrated, dark, painted. The puppets are added by the engine.
- **Never edit the voice.** The picture follows the voiceover; silent chapter cards shift the timeline, never cut the audio.
- **Look before the long render.** Render contact sheets of every shot, inspect them, fix problems, then do one full render.
- You cannot hear audio or watch playback. Verify through alignment numbers, frame checks and loudness readings; tell the user to watch once for timing.
- Keep the user informed with a task list; 10–15 min renders take a while, so give progress updates.

## Stage 0: Pick the market (always first)
Before anything else, even when the user already attached a script or voiceover, ask with **AskUserQuestion** (plain text if the tool is missing): **"Anh muốn làm video cho thị trường nào?"** with four options, Vietnamese first as the recommendation:

| option | code | script, subtitles, labels, voice | speech model (setup) |
|---|---|---|---|
| **Tiếng Việt (khuyên dùng)** | `vi` | Vietnamese | Zipformer Vietnamese |
| English | `en` | English | Parakeet TDT v2 |
| Français | `fr` | French | Parakeet TDT v3 |
| Deutsch | `de` | German | Parakeet TDT v3 |

- If an attached voiceover or script clearly belongs to another language, say so in one line and ask which is right.
- Write the code to `<P>/lang.txt` as soon as the project folder exists (or pass `--lang <code>` once). Every engine command reads it; fonts and the speech model follow it (Vietnamese uses accented fonts).
- If the user later sends a voiceover in another language, ask whether to switch market before aligning.

## Stage 1: 10 horror ideas (start here unless a script/voiceover exists)
- If the user attached a voiceover **and** the script text, go straight to Stage 4. Script but no voiceover → Stage 3 delivery step. Voiceover but no script → ask for the script text (timing needs it).
- Otherwise read `references/ideas-and-scripts.md` and reply with **exactly 10 numbered horror ideas** for a faceless Vietnamese-first mystery channel. Each idea: title (Vietnamese, curiosity-gap), thumbnail text, hook line (first spoken sentence), the dread payoff/twist, why it retains viewers (niche, series potential), the visual world (look + 2–4 key places), best length, and fact status (**truyền thuyết / hư cấu / đã kiểm chứng**).
- Preferred horror menu (mix across the 10): quy tắc sinh tồn trong không gian lạ (khách sạn, bệnh viện bỏ hoang, tàu đêm, khu trọ), truyện ma truyền thuyết địa phương, vụ án/kỳ án bí ẩn, quái vật và dị đoan, creepypasta kiểu "tài liệu bị mất", bút ký thám sát/trở về hiện trường, truyện tâm linh gia đình, sinh tồn trong điều kiện bất thường (sương mù dày, đêm dài, mất điện), người lạ mặt trong nhà, thực thể theo dõi.
- Ask the user to reply with a number, "thêm ý tưởng", or their own topic.

## Stage 2: Pick the length
As soon as they pick an idea, ask: **"Video dài bao nhiêu?"** with exactly four options: **3 phút**, **5 phút**, **10 phút**, **15 phút**, the idea's best length first marked "(Khuyên dùng)". If the story cannot honestly fill the length, say so in one line and suggest the shorter one, but follow their choice. Horror series episodes usually run 5–15 min.

## Stage 3: Script
Write it in the market language following `references/ideas-and-scripts.md`: word/syllable counts per length, horror structure, short spoken sentences, dread re-hooks every 45–75 s, numbers spoken as words in that language.
1. Make the project folder `~/horror-long-form/<slug>/` (or a folder in the working directory when running locally). Write the market code to `lang.txt`. Save the script as `script.txt` (UTF-8), one paragraph per line; chapter-card titles on their own lines starting with `# `.
2. Run `python3 -m engine sentences <P>` to confirm the count and estimated length; adjust until within ±5 % of target.
3. Reply (in Vietnamese) with:
   - the **spoken script** in one copyable block (without `#` chapter lines) in the market language;
   - word/syllable count, estimated length, chapter card titles;
   - the visual plan: main puppets (including any hooded entity), key scenes, ending, and the **background list** (key + one-line place description, 4.1b);
   - fact status (which beats are legend, which were checked);
   - recording tips (from the reference file): one voice, no music, read exactly, mp3/wav/m4a, ElevenLabs settings, native voice;
   - the ask: **"Khi nào có file giọng đọc [ngôn ngữ thị trường] thì anh gửi lên, em dựng video hoàn chỉnh."**
   If they record a changed version, ask for the final text and update `script.txt`.

**Backgrounds while they record (mandatory, saves time):** right after the script, design the video's gloomy world yourself, without asking: read `references/backgrounds.md`, pick the horror `bg_style`, list places and variants, and write `<P>/story.json` with `title`, `mood: "dread"`, `bg_style`, the `frame` block and the full `backgrounds` block (shots can stay empty). Then generate every picture with your image tool (`python3 -m engine bgs <P> --todo` lists missing ones with the exact prompt and save path). Target counts: 3 min ≈ 10–16 pictures, 5 min ≈ 16–24, 10 min ≈ 28–40, 15 min ≈ 40–60. Mention the chosen look and picture count in one line of the visual plan.

## Stage 4: Build the video (after the voiceover arrives)
Work through to the end without stopping. Ask only if something cannot be resolved (voiceover does not match the script at all, or a different market language).

### 4.0 Setup (once per session, per market language)
- Find the skill folder: `find / -name SKILL.md -path "*2d-long-form*" 2>/dev/null` (locally it is the folder this file lives in); treat it as read-only. Call it `<skill>`.
- Run `bash <skill>/scripts/setup.sh <lang>` (`vi`, `en`, `fr` or `de`). It installs skia-python, numpy, scipy, soundfile, sherpa-onnx and downloads that language's offline speech model to `~/models`. Hugging Face may be blocked in sandboxes; GitHub works. If the model download fails, alignment falls back to pause detection (cue timing gets looser) — say so.
- Run every command from the skill folder: `cd <skill> && python3 -m engine <command> <P>`. All output goes into `<P>`.

### 4.1 Voiceover → timing
- Copy the upload to `<P>/voice.<ext>` (mp3, wav, m4a). For several parts: `python3 -m engine join <P> part1.mp3 part2.mp3 ...` → `voice.wav`.
- Run `python3 -m engine align <P>`. It reports `[lang] ... method=asr matched=NN%`. 85 %+ is normal (Vietnamese often 75–90 % due to spellings); below 70 % usually means the recording differs from `script.txt` (ad-libs, another draft) or the wrong market language — check `lang.txt` and ask for the final text.

### 4.1b AI horror backgrounds (mandatory workflow)
Read `references/backgrounds.md` (workflow, horror place catalogue, prompt rules) and the "AI backgrounds + frame" sections of `references/story-format.md`. If pictures were not made in Stage 3, make them now, before the shots.
- **Design:** one `bg_style` for the whole video (cold dark painted horror); one entry per place × hour; a wide and a close/angle variant for every place used many times; 2–4 soft dark backdrops for graphics shots. Prompts in English whatever the market language.
- **Make them yourself, abundantly:** `python3 -m engine bgs <P> --todo` prints every missing picture (key, full prompt, `save_as`). Generate each as a 16:9 picture with your image tool and save it there; run independent generations in parallel. Then `python3 -m engine bgs <P> --provider manual` to normalize to 1920×1080 and build `work/bg_sheet.jpg`.
- **No image tool?** `python3 -m engine bgs <P>` uses a configured key (Cloudflare `CF_ACCOUNT_ID` + `CF_API_TOKEN`, `POLLINATIONS_KEY`, `GEMINI_API_KEY`, `OPENAI_API_KEY`), otherwise the free anonymous route (slow ~45 s/picture, lower quality, small watermark). Or send `bg/PROMPTS.md` to the user and import their upload with `--import <zip|folder>`. Other flags: `--only k1,k2`, `--force k1,k2` (new seed).
- **Inspect `work/bg_sheet.jpg`:** regenerate pictures with people/faces, text, watermarks, a bright style, mismatched palette, or no open lower-third floor. Show the sheet to the user in one Vietnamese line; keep going without waiting.
- Missing pictures never stop the build: those few shots use the dark `horror` code set — treat it as an emergency gap filler, not a style.

### 4.2 Storyboard (`<P>/story.json`)
Read `references/story-format.md` fully and look at the example folder (it uses every useful shot kind). Run `python3 -m engine sentences <P>` first, then write `story.json`:
- `cast`: 2–5 original puppets with distinct silhouettes/colours; optional hooded entity (`outfit: "cloak", hood: true`) for the supernatural being; faces: `terror`, `scared`, `panic`, `nervous`, `worried`, `shocked`, `creepy`.
- `frame`: identity block — `channel` (the user's channel name; badge + watermark), `disclaimer` text (default fiction warning; keep on), `captions: true` (hard subtitles from the voice), `badge`, `watermark`, `paws` (navy paw strips).
- `shots`: cover every sentence number once, in order, roughly one shot per 3–8 s (3 min ≈ 30–40 shots, 15 min ≈ 150–190). Rotate world shots (wide, closeup, walk, skyline) and graphics shots (icon, list, table, versus); a reaction `closeup` after every scare or twist; chapter cards every 2–3 min in 10–15 min videos.
- **Every on-screen text in the market language** (labels, tags, lower thirds, documents, chapter cards). Subtitles are automatic; do not duplicate them as labels.
- Cue mid-shot events with words from the shot's sentences (`"at": "bóng"`), written exactly as in the script.
- `mood`: use `"dread"` for horror; `"tense"` for chase/survival beats; `"mystery"` for clue chapters.
- **`bg` on every world shot and chapter card**, on some graphics shots; change the picture whenever place or hour changes; alternate wide/close variants; never hold one picture more than about 4 shots in a row.
- Scare beats: `"sfx": [{"name": "scare", "at": "..."}, {"name": "creak"}, {"name": "heartbeat"}, {"name": "whisper"}]`; footsteps on walks; `sting` on the final reveal.
- For 10–15 min videos, write shots in chunks (one chapter at a time) and run `plan` after each chunk.

### 4.3 Plan check
Run `python3 -m engine plan <P>`. Fix every warning (uncovered sentences, cue words not found, shots shorter than 6 frames). Split shots longer than ~10 s; merge fragments under 1.5 s into a neighbour.

### 4.4 Look check (before the long render)
- Run `python3 -m engine stills <P>` (contact sheets in `work/sheet_N.jpg`; `--shots 3,8,12 --fracs .2,.6,.95` for detail).
- Inspect every sheet. Background fixes: feet floating/sinking (set `floor`), puppets too big/small (`char_s`), busy picture behind captions (`bg_dim`, `bg_blur`), puppet too bright/dark (`tint`), wrong picture (`bgs <P> --force key`). Other fixes: labels over a face (move `x/y`), text too long, missing accents (check `lang.txt`), off-frame characters in wides (`x` between 250 and 1670), same kind twice in a row, empty graphics shot.
- Confirm the disclaimer banner, badge and a subtitle frame read correctly. Send the sheet(s) to the user with one line, then start the render without waiting.

### 4.5 Render
- Run `python3 -m engine render <P>` **in the background** (`run_in_background`, or `nohup ... > <P>/work/render.log 2>&1 &`); check progress every few minutes. It prints `[done/total] ... ETA`, uses most cores, renders shots in parallel and **resumes** after interruption (finished shots are cached). Change one shot → only that shot re-renders (`render <P> --shots 12,13` also re-joins).
- Speed (8 cores measured): 1080p ≈ 3–4 render-minutes per video-minute; `--res 720` ≈ half. On 2 cores expect ~3–4× that. Check `nproc` first; a 10–15 min 1080p render over ~60–90 min on a small sandbox: tell the user the estimate and offer `--res 720`. Pass the same `--res` to `render`, `audio`, `final`, `all`.

### 4.6 Sound + final
- `python3 -m engine audio <P>`: dread/suspense music bed built from `mood`, SFX from shot events (scare stings, creaks, heartbeat, whispers, steps, booms on chapter cards, shutter on the polaroid ending), music ducked under speech, mastered to about −14 LUFS; the voice is untouched. Levels print: music should sit about −18 to −21 dB under speech. Use `--music-db -20` for a quieter bed.
- `python3 -m engine final <P>` muxes `<P>/out/<title>.mp4`.
- Or run everything after the storyboard: `python3 -m engine all <P>` (it does **not** generate backgrounds: run `bgs` first).

### 4.7 Verify and deliver
- `ffprobe` the MP4: 1920×1080, 30 fps, duration ≈ voiceover + chapter cards + ~1 s.
- Pull 6–8 frames at cue moments (`ffmpeg -ss <t> -i out.mp4 -frames:v 1 f.jpg`) and inspect: subtitle up, scare sting frame, mouth moving on dialogue, accents correct, disclaimer and badge present, no picture showing people/text.
- Deliver the MP4 (file path / SendUserFile) with, in Vietnamese: market, length, a few lines on scenes and the number of AI backgrounds used, legend-vs-checked fact notes, an offer of tweaks ("đổi shot nào thì anh báo số"), and the next horror idea from the list. Remind them to watch once for timing and to replace the placeholder channel name with their own in the `frame` block.

## Engine map (for edits beyond story.json)
- `engine/kit.py`: colours, easing, ink shapes, night lighting, grade and bloom; puppet `draw_char()`; emotions including `terror/scared/panic/creepy`; `outfit: "cloak"` with `hood: true` (hooded skull entity, optional red `glow` eyes); fonts picked by market language (`RM_LANG`).
- `engine/frame.py`: broadcast identity overlay — navy paw strips, fiction disclaimer banner, channel badge, automatic hard subtitles from the current sentence, watermark. Configured by the story.json `frame` block.
- `engine/aibg.py`: AI backgrounds — prompt building (horror `DEFAULT_STYLE`, horror `TIME_HINT`), providers (Cloudflare, Pollinations, Gemini, OpenAI, free anonymous), import/normalize to 1920×1080 JPEG, `bg_sheet.jpg`. `Shot.ai_bg()` draws the picture per shot; `tint_look()` matches puppets to the picture's light.
- `engine/sets.py`: fallback sets; `horror` (dark abandoned corridor) is the default last-resort set for world shots. `table`, `map`, `board` keep their drawn look for graphics.
- `engine/props.py`: documents and icons; add a new icon as `ic_name(c, t, o)` and register in `ICONS`.
- `engine/fx.py`: pop labels, stamps, tags, lower thirds, typed cards, bubbles, badges.
- `engine/shots.py`: shot kinds (`KINDS`); a new kind subclasses `Shot` with `world()`, `over()`, `screen()`.
- `engine/timing.py`: sentence splitting; ASR word timestamps (accent-insensitive; model per `RM_LANG`); pause fallback. `engine/timeline.py`: shot times, cues, silent-card gaps, sentence spans used by subtitles.
- `engine/audio.py`: music moods incl. `"dread"` (slow pulse pad, sparse bell motif) and `"tense"`; SFX incl. `scare`, `creak`, `heartbeat`, `whisper`, `sting`; mix and −14 LUFS loudness.
- `engine/render.py`: camera, whips, shake, polaroid, parallel segment render, contact sheets; draws `frame.draw_overlay()` after the grade.
- **Performance rule:** CPU skia is slow at full-frame gradients, blends, filters and rotated image draws. Static art goes into per-shot caches built in `Shot.prepare()`; full-frame passes run in numpy. Per-frame drawing = vector shapes and axis-aligned image blits only.

Style bible (keep when extending): one uniform near-black ink line (#18161B, 6 px at 1080p); flat fills with one hard shadow; white round puppet heads; cold desaturated navy/blue-grey painted worlds with fog and one sickly warm light; sweat drops and wide eyes on dread beats; navy strips with paw prints; white uppercase hard subtitles on a translucent black band; red used only for the disclaimer bar, the badge accent and warning stamps; typed-white chapter cards; a heavier vignette than cheerful templates; music low and pulsing, SFX sudden.

---
*Horror Long Form. Third-party credits: `CREDITS.md`.*
