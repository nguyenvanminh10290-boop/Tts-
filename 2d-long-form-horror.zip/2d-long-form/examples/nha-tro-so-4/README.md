# Example: Tập 1 — Bảy Quy Tắc Ở Nhà Trọ Số 4

A short (~3 min, 33 spoken sentences) rules-of-survival horror episode in the skill's new identity:
cold AI-painted night backgrounds, round-head puppets, a hooded entity, hard subtitles, the fiction
disclaimer banner and the navy paw strips. Use it as the schema reference when writing a real
`story.json`.

## Files
- `script.txt` — spoken Vietnamese script; chapter titles on `# ` lines; one sentence per line.
- `story.json` — storyboard: `frame` identity block, `cast`, `backgrounds` prompt block, `shots`.

## Horror-specific pieces in this example
- `frame.channel` placeholder (replace with the creator's own channel name), `disclaimer` warning on,
  `captions: true` (subtitles are generated automatically from the voice; never scripted as labels).
- `cast.bong`: `outfit: "cloak"`, `hood: true`, `glow: true` — the hooded skull figure.
- `mood: "dread"`; SFX: `tick`, `thud`, `creak`, `heartbeat`, `whisper`, `ding`, `whoosh`.
- Background keys with English prompts; the agent generates these pictures itself at runtime with
  its image tool (`engine bgs <P> --todo` → generate → `bgs <P> --provider manual`). No pictures
  ship in the skill; missing keys fall back to the dark `horror` code set only temporarily.
- Shot mix: wide establishing, closeup reactions (`terror`, `scared`, `panic`), rule `list`, note
  `table`, `versus` beat, `walk` escape, `skyline` dawn closing, three silent `title` chapter cards.

## Run order (real project)
1. `bash <skill>/scripts/setup.sh vi`
2. `python3 -m engine sentences <P>` (check the 33-sentence estimate)
3. Design `backgrounds`, generate pictures, `python3 -m engine bgs <P> --provider manual`
4. Voiceover → `python3 -m engine align <P>`
5. Fill `shots`; `python3 -m engine plan <P>`; `stills <P>`; `render <P>`; `audio <P>`; `final <P>`

## Fiction note
All characters and places are fictional; the final spoken line carries the cautionary reminder and
the banner keeps the disclaimer on screen throughout.
