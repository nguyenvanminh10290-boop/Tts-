# Horror niche: ideas and scripts (Vietnamese-first, markets: vi / en / fr / de)

## 1. Channel brief
Faceless long-form horror narration with round-head ink puppets over AI-painted dark worlds. The narrator (the user's voice) tells a first- or third-person mystery; the audience stays for the **next unknown rule, the next strange detail, the final twist**. Episodes are hư cấu (fiction) by default; legends are labelled as truyền thuyết. Series episodes end with a hook; standalone episodes end with a cautionary or reassuring line.

## 2. Idea menu (mix all ten pitches; keep one dominant format)
1. **Quy tắc sinh tồn** trong một nơi lạ (khách sạn, bệnh viện bỏ hoang, khu trọ, tàu đêm, trường học sau giờ đóng cửa): một danh sách quy tắc, mỗi quy tắc là một phen nguy hiểm.
2. **Truyện ma truyền thuyết địa phương**: ngôi làng, con sông, ngôi nhà, con đường có lời đồn; người kể quay lại hiện trường.
3. **Kỳ án / vụ án bí ẩn**: chuỗi manh mối, bằng chứng lạ, một kết luận không giải thích được hoàn toàn (không nêu tên nạn nhân/người thật).
4. **Quái vật và dị đoan**: thực thể từ từ lộ diện qua dấu vết (tiếng động, bóng đen, vật dụng đổi chỗ).
5. **Tài liệu bị mất / creepypasta**: nhật ký, ghi chú, bản ghi âm, "đoạn tin nhắn cuối cùng" dựng thành lời kể.
6. **Bút ký thám sát**: nhóm nhỏ đi vào khu vực cấm; POV tâm lý, đội hình căng thẳng dần.
7. **Tâm linh gia đình**: vật truyền đời, nghi lễ trong nhà, tổ tiên thờ cúng, điều cấm kỵ vô tình bị vi phạm.
8. **Sinh tồn bất thường**: sương mù dày, mất điện đêm dài, nước dâng, phong tỏa; luật sống còn thay đổi liên tục.
9. **Người lạ mặt trong nhà / kẻ theo dõi**: những thay đổi nhỏ trong nhà, cảm giác bị nhìn thấy, không khí ngột ngạt từng bước.
10. **Thực thể trùm áo choàng**: nhân vật phản diện siêu nhiên ít xuất hiện, uy hiếp bằng bóng và tiếng động (dùng `outfit: "cloak", hood: true`).

## 3. Idea pitch format (Stage 1 output, exactly 10 numbered items)
Each item:
- **Tiêu đề** (tiếng Việt, có khoảng trống tò mò; không giật tít quá lố);
- **Chữ thumbnail** (4–7 từ, cùng giọng);
- **Câu mở đầu** (hook, câu nói đầu tiên của giọng đọc);
- **Điểm căng thẳng cao nhất / Twist**;
- **Giữ chân người xem**: nhánh series, tập tiếp theo hứa gì;
- **Thế giới hình ảnh**: phong cách nền + 2–4 địa điểm chính (khớp catalogue trong `backgrounds.md`);
- **Độ dài gợi ý**;
- **Trạng thái tư liệu**: `truyền thuyết` / `hư cấu` / `đã kiểm chứng` (chỉ dùng `đã kiểm chứng` cho sự kiện công khai đã tra cứu; không bịa số liệu).

## 4. Horror script structure
- **Cold open (0:00–0:35):** một hình ảnh câu chốt (tiếng động lạ, quy tắc đầu tiên, cảnh tượng bất thường) rồi quay lại "trước khi mọi chuyện xảy ra".
- **Thiết lập (0:35–1:30):** nhân vật, bối cảnh, luật chơi (nếu là quy tắc sinh tồn), giọng điệu bình thường rồi nứt một vết.
- **Chuỗi căng thẳng leo thang:** 4–8 chặng; mỗi chặng = một manh mối/sự kiện lạ + một phản ứng sợ hãi của nhân vật; xen cảnh đối thoại ngắn và cảnh một mình.
- **Cao trào:** quy tắc bị vi phạm / thực thể xuất hiện / bí mật được mở.
- **Kết:** giải thích hợp lý một phần, giữ lại một ẩn số; câu cảnh báo hoặc trấn an; hook tập sau nếu là series.
- Re-hook mỗi 45–75 giây: một câu hỏi treo, một chi tiết chưa giải thích, một câu dự báo ngắn ("Nhưng điều đáng sợ nhất chưa đến.").

## 5. Length and counts (speak slowly, short sentences; pauses breathe)
| target | syllables (vi) / words (en/fr/de) | sentences | chapter cards |
|---|---|---|---|
| 3 min | 480–560 (vi) / 420–480 (en) / 430–490 (fr) / 410–470 (de) | 55–75 | 1 |
| 5 min | 780–920 / 680–790 / 700–810 / 660–770 | 90–125 | 1–2 |
| 10 min | 1 550–1 850 / 1 350–1 580 / 1 400–1 620 / 1 320–1 540 | 180–250 | 3–4 |
| 15 min | 2 300–2 700 / 2 000–2 350 / 2 080–2 400 / 1 960–2 280 | 270–370 | 5–6 |

Run `python3 -m engine sentences <P>`; adjust until within ±5 % of target. Numbers are spoken as words (vi: "mười hai giờ đêm", not "12h"); units and time follow market custom.

## 6. Line rules
- One sentence per line (one paragraph per line in `script.txt`); average 8–16 syllables (vi) / 6–12 words (en/fr/de). Short sentences for scares; one slightly longer descriptive line per scene change.
- Speakable Vietnamese: no academic idioms, no homophone traps; each sentence = one shot beat.
- Cue-able concrete words for sound/motion: bóng đèn, cánh cửa, tiếng gõ, bước chân, gương, bóng đen, tiếng thì thầm, rương, cầu thang, công tắc.
- Chapter-card title lines start with `# ` (e.g. `# CHƯƠNG 1: QUY TẮC ĐẦU TIÊN`); they become silent typed cards and shift the timeline; do not put them inside the spoken block sent to the user.
- On-screen text (labels, documents, notes) lives in `story.json`, not in the spoken script; keep the voiceover pure speech.

## 7. Safety and fiction guardrails
- Mở đầu và banner khung hình xác nhận: nội dung hư cấu. Không dựng hình nghi lễ khả thi thành hướng dẫn; chỉ mô tả không khí và cảm giác.
- Không tả máu me, bạo lực xác thịt chi tiết; nỗi sợ đến từ bóng tối, tiếng động, sự bất thường và phản ứng nhân vật.
- Không dùng tên người thật, nạn nhân thật, địa chỉ thật của vụ án còn lưu vong; truyền thuyết địa phương nói rõ "đây là lời đồn".
- Kết thúc nguy hiểm (chui vào nơi cấm, chơi bùa, gọi linh hồn) phải có câu răn: "đừng bắt chước", "truyền thuyết chỉ để kể".
- Thuật ngữ tôn trọng: tránh báng bổ; dùng từ trung tính cho yếu tố tâm linh.

## 8. Recording tips to send with the script
- Một giọng đọc duy nhất; không nhạc nền, không tiếng ồn phòng; micro cách miệng 15–20 cm; đọc chậm, hạ giọng ở câu cuối mỗi đoạn.
- Đọc đúng từng chữ trong file; không tự thêm bớt; ngừng lâu hơn giữa các chương (engine cắt theo khoảng lặng).
- File: mp3 / wav / m4a, đơn kênh cũng được; nếu dùng ElevenLabs: giọng native vi (giọng trầm, ấm), stability ~0.45–0.55, style ~0.2, speed ~0.95; với en/fr/de chọn giọng hợp thị trường.
- Nhiều phần: gửi theo thứ tự; `engine join` ghép thành `voice.wav`.
