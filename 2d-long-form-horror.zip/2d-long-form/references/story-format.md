# `story.json` format (horror build)

One JSON file in the project folder. Top-level keys: `title`, `mood`, `bg_style`, `frame`, `cast`, `backgrounds`, `shots`. Market language comes from `lang.txt`; every piece of on-screen text must already be in that language.

```json
{
  "title": "Tập 1: Quy Tắc Trong Nhà Trọ Số 4",
  "mood": "dread",
  "bg_style": "horror-painted",
  "frame": { "channel": "TÊN KÊNH CỦA ANH", "captions": true, "badge": true,
             "watermark": true, "paws": true,
             "disclaimer": "NỘI DUNG VIDEO CHỈ LÀ HƯ CẤU KHÔNG CÓ THẬT · KHÔNG BẮT CHƯỚC HAY LÀM THEO!" },
  "cast": { "nam": { "outfit": "hoodie", "color": "#3B4660", "hair": "short" },
            "bóng": { "outfit": "cloak", "hood": true, "glow": true, "color": "#2C2738" } },
  "backgrounds": { "tro_hall_night": { "prompt": "...", "time": "night", "floor": 1010 } },
  "shots": [ { "kind": "wide", "s": [0], "bg": "tro_hall_night", "chars": [ ... ] } ]
}
```

## 1. `frame` — broadcast identity (all fields optional; horror defaults ON)
| field | default | meaning |
|---|---|---|
| `on` | `true` | master switch; `false` hides the whole overlay |
| `channel` | `"KÊNH KINH DỊ"` | channel name; used by the top-right badge and the `YTB: …` watermark. Put the creator's own name here; never copy another channel's name |
| `disclaimer` | fiction warning string | top-left red-barred banner; keep it on for horror; `false` to hide |
| `badge` | `true` | top-right channel badge lettering |
| `captions` | `true` | hard subtitles: the currently spoken sentence, uppercase white on a translucent black band; driven automatically by voice timing (silent chapter cards show none) |
| `watermark` | `true` | small `YTB: <channel>` line bottom-right |
| `paws` | `true` | navy top/bottom strips with paw prints |

## 2. `cast` — object, id → look
```json
"nam": { "skin": "fair", "outfit": "hoodie", "color": "#3B4660", "shirt": "#E8E0D0",
         "hair": "short", "hair_col": "#1C1B22", "glasses": false, "beard": false }
```
- `outfit`: `suit`, `hoodie`, `tshirt`, `dress`, `sweater`, **`cloak`** (hooded entity robe).
- Hooded entity (supernatural being): `"outfit": "cloak", "hood": true`, optional `"hood_col": "#2C2738"`, `"glow": true` (faint red eyes); hair/hat ignored.
- `hair`: `short`, `long`, `bun`, `curly`, `bald`, `slick`; `hat`: `fedora`, `cap`; extras `beard`, `moustache`, `glasses`, `hanky`.

## 3. `backgrounds`
See `backgrounds.md` for the catalogue, style table and prompt rules. Entry:
```json
"tro_hall_night": { "prompt": "narrow guesthouse corridor at night, greenish bulbs, numbered doors, worn tiles, one door slightly ajar, fog low on the floor, wide eye-level shot", "time": "night", "floor": 1010 }
```
`time`: `night` | `dusk` | `day`; optional `floor`, `char_s`, `tint`. Files live in `bg/<key>.jpg`; world shots reference the key in `bg`.

## 4. Shot common fields
| field | meaning |
|---|---|
| `kind` | one of the kinds in section 5 |
| `s` | sentence numbers covered, e.g. `[3, 4]`; every sentence covered once, in order |
| `at` | cue word from the script for mid-shot events (must appear in covered sentences) |
| `bg` | background key from `backgrounds`; prefer on world shots, chapter cards, some graphics shots |
| `set` | fallback code set name only when `bg` missing (`horror` default); rarely used |
| `time` | `night` / `dusk` / `day`; overrides the picture hint for lighting |
| `floor` | standing height px (default ≈1010–1024); fix floating/sinking feet |
| `char_s` | puppet scale override; `tint` hex pulls puppets toward the picture's light |
| `bg_dim`, `bg_blur`, `bg_zoom`, `bg_shift` | darken / blur / zoom / shift the picture behind text |
| `labels` | `[{"text": "...", "at": "...", "color": "lime|cream|red", "x": 1300, "y": 300, "font": "marker", "rot": -3}]` |
| `stamp` | `{"text": "TRUYỀN THUYẾT", "at": "...", "x": 1420, "y": 360, "color": "red"}` |
| `sfx` | `[{"name": "scare", "at": "cửa", "dur": 0.9}, {"name": "heartbeat"}]`; optional `vol`, `pitch` |
| `cam` | `{"zoom": [1.0, 1.08], "focus": [[960,545],[960,545]], "rot": 0.6}` |
| `shake` | shake strength on a scare beat; `note` free comment |

Actor entry inside `chars` (world shots) or `who` (closeup):
```json
{ "id": "nam", "x": 760, "s": 0.9, "face": 0.5, "emotion": "terror",
  "pose": "think", "talk": 0, "walk": [300, 1500],
  "beats": [{"at": "bóng", "emotion": "panic", "face": -0.8}] }
```
`pose`: `idle`, `think`, `explain`, `point`, `hold`, `pockets`, `arms_crossed`, `celebrate`; `emotion`: any cast emotion incl. `terror`, `scared`, `panic`, `creepy`; `walk`: start/end px on walk shots; `talk`: index of the speaking actor in dialogue.

## 5. Shot kinds
| kind | key fields | use |
|---|---|---|
| `wide` | `bg`, `chars[]`, `dist`, `floor`, `tag`, `lower_third`, `props` (icon/x/y/s) | establishing place; puppets in frame |
| `dialogue` | `bg`, `chars[]` with `talk` | two+ puppets exchanging lines; auto talking mouth |
| `walk` | `bg`, `chars[]` with `walk`, `speed` | moving through place; repeated footsteps SFX |
| `closeup` | `who`, `side` (`left`/`right`), `emotion`, `beats`, `bubble` | reaction beat after every scare/twist |
| `skyline` | `bg`, `tag`, `chars[]` | exterior wide pull |
| `crowd` | `count`, `emotion`, `highlight`, `at` | group scene; highlight one id |
| `versus` | `left: {who,title,emotion,at}`, `right: {...}`, `colors` | two forces/characters face off |
| `table` | `items: [{type,title,text,stamp,ring_at,at}]`, `hand` | evidence, documents, notebook pages, phone messages (`type`: `newspaper`, `cash`, `phone`) |
| `chart` | `board` (`chalk`/`white`), `chart: {type: bar|line, values, labels, title, at, highlight, trend}` | numbers, comparisons |
| `counter` | `value: {from,to,prefix,suffix,at,dur}`, `caption`, `icon`, `compare: {text,at,icon}` | escalating count, body count-style ticks (fiction) |
| `icon` | `icons: [{name,label,top,text,at,x,y}]`, `chars[]` | single-symbol beat (props icons in `props.py`) |
| `list` | `number`, `text`, `who`, `emotion`, `items` | rules checklist, clue list |
| `map` | `places: [{name}]`, `at` | route through a territory |
| `title` | `text`, `sub`, `words`, `word_s`, `bg`, `card: true` | silent chapter card (no `s` when fully silent; `s` allowed if a sentence spans it) |

`polaroid`: a property on a final `wide` shot — `{"polaroid": {"at": "wait", "who": "nam", "caption": "..."}}`; shutter SFX plays.

## 6. SFX names
`pop`, `thud`, `whoosh`, `tick`, `shutter`, `scribble`, `boom`, `ding`, `paper`, `step`, `sting`, plus horror set: **`scare`** (sudden sting burst), **`creak`** (door/wood), **`heartbeat`** (low double thump), **`whisper`** (filtered breath). Place `scare` on the scare cue; `heartbeat` under dread closeups; `creak` / `whisper` on place entries; `sting` on the final reveal.

## 7. Music moods
`dread` (default horror: slow low pad, sparse bell, heartbeat pulse), `tense` (chase/survival), `mystery` (clue chapter), `cheerful`, `calm`, `sad`, `swing`, `pop`, `heavy`, `none`. Top-level `"mood"`; a shot may override.

## 8. Horror storyboard checklist
- Cover every sentence once, in order; one shot ≈ 3–8 s; avoid two identical kinds back to back except a reaction pair.
- `bg` on every world shot; switch key on place/hour change; alternate wide/close variants; no picture held > ~4 shots.
- Reaction `closeup` after each scare; `scare` SFX on its cue; chapter `title` cards every 2–3 min for long videos.
- Labels/documents in market language; subtitles are automatic — never repeat spoken lines as label text.
- Final beat: cautionary/reassuring line or series hook; end on a `dread`-mood wide (optional polaroid).
- Validate: `python3 -m engine plan <P>` must print no warnings before rendering.
