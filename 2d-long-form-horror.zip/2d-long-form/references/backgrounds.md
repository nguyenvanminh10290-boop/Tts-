# AI horror backgrounds — mandatory and plentiful

The world of every video is a **painted AI picture**. The engine draws the puppets, props and captions on top; it never invents a room in code by default. The agent running this skill designs and generates the pictures itself, at runtime, with its image tool. Nothing ships inside the skill as a pre-made background.

**Goal: as many pictures as the story supports.** A video that repeats one gloomy painting for 15 minutes looks cheap. Each distinct place, each change of hour, each new angle and each graphics beat should have its own picture; pictures alternate between wide establishing shots and close/side angles so the edit breathes.

## 1. Workflow (do this right after the script, while the user records)
1. Read `script.txt`, list every place and hour mentioned (e.g. "hành lang bệnh viện bỏ hoang ban đêm", "căn phòng trọ lúc nửa đêm", "rừng sương lúc tờ mờ sáng").
2. Pick one `bg_style` for the whole video (table below).
3. Write the `backgrounds` block in `<P>/story.json`: one entry per picture key. Leave `shots` empty for now if the voiceover has not arrived.
4. Run `python3 -m engine bgs <P> --todo` — it lists every missing key with the full prompt and the exact `save_as` path.
5. Generate every missing picture **in parallel batches** with the agent's own image tool (16:9, 1920×1080 or larger), save it to `save_as`. No image tool? Use `bgs <P>` providers (section 6) or send `bg/PROMPTS.md` to the user and import their uploads (`bgs <P> --import <zip-or-folder>`).
6. Run `python3 -m engine bgs <P> --provider manual` to normalize everything to 1920×1080 JPEG and build `work/bg_sheet.jpg`.
7. Inspect the sheet (section 5), regenerate rejects, then keep going into the storyboard. Pictures never block the build: a missing picture temporarily falls back to the dark `horror` code set until its image exists, then rerun `bgs` and `render --shots <n>`.

## 2. How many pictures
| target length | minimum | comfortable | breakdown |
|---|---|---|---|
| 3 min | 10 | 12–16 | 5–8 places × wide + 1 close; 2–3 graphics backdrops |
| 5 min | 16 | 18–24 | 8–12 places × wide/close; 3–4 graphics backdrops |
| 10 min | 28 | 32–40 | 12–18 places × wide/close/angle; 4–6 graphics backdrops; 2 hour variants |
| 15 min | 40 | 46–60 | 18–26 places × wide/close/angle; 6–8 graphics backdrops; 3–5 hour variants; chapter-card title frames |

Rules: a place used in ≥3 shots gets a wide **and** a close/angle variant. An hour change (night → pre-dawn, dusk → night) gets a new picture, not a recolour. Graphics shots (icons, lists, tables) use soft dark backdrops so labels stay readable.

## 3. Prompt anatomy (English, regardless of market language)
```
<bg_style prefix> + <place description, camera angle, props in the room> + <hour hint from aibg.TIME_HINT> + <rules suffix>
```
- Place description: where, era or lack of era, one or two props that carry the story (rotating fan, cracked mirror, overturned chair, handwritten note on a desk), camera position (wide establishing / close corner / low angle through a doorway).
- Hour hint: `night` (cold blue moonlight, fog, one faint warm glow), `dusk` (dead blue-violet overcast), `day` (pale grey sickly light, haze).
- Rules suffix is added automatically by the engine; do not duplicate it, but keep the prompt free of people.

## 4. `bg_style` choices (pick one per video)
| key | style prefix (the engine appends it automatically) | when to use |
|---|---|---|
| `horror-painted` (default) | dark atmospheric 2D painted horror illustration, rough ink outlines, cold desaturated navy-blue and grey palette, thin fog, film grain and scratches, dim sickly light, hand-painted brush texture, melancholic dread | most horror narration; the Cáo-Hồi-Hộp-style look |
| `ink-sketch` | grim pencil-and-ink sketch on aged paper, heavy cross-hatching, charcoal blacks, washed blue-grey stains, unsettling hand-drawn line | first-person notebook / "tài liệu bị mất" |
| `faded-photo` | faded old photograph aesthetic, desaturated cyan-grey, heavy vignette, dust and scratches, slight motion blur, no faces anywhere | found-footage / archive memory chapters |
| `night-surveillance` | grainy night-surveillance camera look, infrared green-blue tint, scan lines, wide-angle distortion, empty corridors, dim light circles | security-camera / rules-of-survival chapters |
| `folk-wash` | Vietnamese rural folk-horror wash illustration, indigo and earth-brown ink wash, misty village shapes, sparse trees, folk masks hanging on walls | village legends, local folklore |

## 5. Horror place catalogue (keys + seed prompts; adapt names per story)
Use these keys verbatim or extend the pattern; the `#` comment after each line describes the picture.
```json
"backgrounds": {
  "ward_hall_night":   {"prompt": "long abandoned hospital corridor at night, peeling walls, one hanging bulb with weak blue light, rows of empty door frames, a wheelchair tipped over, cold fog on the floor, wide eye-level shot", "time": "night"},
  "ward_hall_close":   {"prompt": "close corner of the abandoned corridor, cracked tiles, an old medical cabinet with drawers half open, papers scattered, faint light from a far window, side angle", "time": "night"},
  "morgue_room":       {"prompt": "small cold morgue room, rows of metal drawers, one drawer slightly pulled out, a single bare bulb, greenish tiles, oppressive silence, wide shot", "time": "night"},
  "ritual_room":       {"prompt": "secret meeting room behind frosted glass, a long table with old papers and candles, chairs facing one empty head, dim blue window light through the frost, wide shot", "time": "night"},
  "fog_forest":        {"prompt": "deep forest at night covered in thick white fog, twisted bare trees, a narrow muddy path disappearing into mist, cold moonlight from above, wide shot", "time": "night"},
  "graveyard_dusk":    {"prompt": "old village graveyard at blue dusk, crooked wooden crosses, low mist between stones, bare trees silhouettes, no people, wide shot", "time": "dusk"},
  "old_house_room":    {"prompt": "locked room in an old two-storey house, dusty window with boards, a rocking chair, faded family photo face-down on the floor, weak daylight through cracks, wide shot", "time": "day"},
  "attic_night":       {"prompt": "dark attic under a tiled roof, beams and spider webs, old chest and stacked cardboard boxes, moonlight through a small broken window, close angle", "time": "night"},
  "basement_stairs":   {"prompt": "concrete basement stairs going down, a bare wire hanging, damp stains on walls, darkness at the bottom, low-angle shot", "time": "night"},
  "well_yard":         {"prompt": "neglected courtyard of a rural house at night, an old stone well with a broken bucket, dry vines, wooden fence behind, cold moon, wide shot", "time": "night"},
  "night_bus":         {"prompt": "empty night intercity bus interior, dim yellow dashboard glow, rows of empty seats, rain on windows, dark road outside, wide shot", "time": "night"},
  "train_car":         {"prompt": "old overnight train carriage at night, swaying empty berths, a single reading lamp, fogged window, wide shot", "time": "night"},
  "motel_room":        {"prompt": "cheap roadside motel room late at night, narrow bed, a TV turned off reflecting light, thin curtains, greenish hallway light leaking under the door, wide shot", "time": "night"},
  "alley_rain":        {"prompt": "narrow alley in the rain at night, puddles reflecting a flickering sign, stacked crates, walls covered in scratches, low angle", "time": "night"},
  "school_class_night":{"prompt": "empty classroom late at night, overturned desks, a broken blackboard, dust in the beam of a flashlight, wide shot", "time": "night"},
  "mine_tunnel":       {"prompt": "narrow mine tunnel with wooden supports, tracks disappearing into blackness, one lantern glow on the wall, close wide shot", "time": "night"},
  "riverside_mist":    {"prompt": "riverbank in early mist, small broken boat tied to a pole, reeds, grey water, far bank barely visible, wide shot", "time": "dusk"},
  "church_ruin":       {"prompt": "roofless old chapel ruin at dusk, broken pews, cracked arched window, overgrown weeds, wide shot", "time": "dusk"},
  "shrine_altar":      {"prompt": "small household shrine corner at night, faded curtains, burnt incense sticks, old papers and charms, one candle, close shot", "time": "night"},
  "swamp_edge":        {"prompt": "swamp edge at night, black water, cypress knees, hanging moss, fog low over the water, wide shot", "time": "night"},
  "locked_cell":       {"prompt": "small locked cell, iron bars, a thin blanket on stone, a slit window high on the wall, cold grey light, wide shot", "time": "day"},
  "surveillance_room": {"prompt": "dark control room with a wall of small monitors showing empty hallways, one desk and a chair, green-blue screen glow, wide shot", "time": "night"},
  "tunnel_underpass":  {"prompt": "concrete pedestrian underpass, damp walls with graffiti scratches, one flickering lamp, stairs at both ends swallowed by dark, wide shot", "time": "night"},
  "mirror_hall":       {"prompt": "old dressing room wall covered with cracked mirrors, one mirror dark and fogged, candle on the floor, close angle", "time": "night"},
  "bg_notes":          {"prompt": "very dark soft-blue paper texture with faint ink stains and a few ruled lines, no writing, empty centre, wide backdrop", "time": "night"},
  "bg_desk":           {"prompt": "top-down dim wooden desk surface, scattered old paper sheets, a fountain pen and a candle at the edge, shadows at the corners, no text on papers", "time": "night"}
}
```
Village / period / profession variations replace the props and the architecture while keeping the cold palette.

## 6. Hard prompt rules (reject violations, regenerate)
- **No people, faces, silhouettes of people, hands or animals.** Puppets are overlaid later.
- No readable text, letters, signs with writing, posters with words, logos, watermarks, artist signatures, or named movie/game/channel styles.
- 2D illustrated or painted; not a photo, not a 3D render, not anime cel-shading, no bright cheerful colours.
- Keep the lower third relatively open and dark: puppets stand there. Busy ground clutter belongs in the upper half or far background.
- Consistent palette across the set (the `bg_style` prefix locks it); one warm accent per picture at most (bulb, candle, lantern).
- 16:9 landscape; no borders, no frame within the frame.

## 7. Providers and commands
- `python3 -m engine bgs <P> --todo` — list missing keys with prompts and paths.
- `python3 -m engine bgs <P>` — generate with the first configured key: Cloudflare (`CF_ACCOUNT_ID`, `CF_API_TOKEN`), Pollinations (`POLLINATIONS_KEY`), Gemini (`GEMINI_API_KEY`), OpenAI (`OPENAI_API_KEY`); otherwise the free anonymous route (slow, ~45 s/picture, lower fidelity, tiny watermark — inspect and reject when the watermark shows).
- `python3 -m engine bgs <P> --provider manual` — normalize existing files (resize to 1920×1080 JPEG, build `work/bg_sheet.jpg`).
- `python3 -m engine bgs <P> --import <zip|folder>` — ingest user-drawn/downloaded pictures (match by filename key).
- `--only k1,k2`, `--force k1,k2` (regenerate with a new seed), `--style <key>` override.
- Per-shot tuning (engine fields, no new image needed): `floor` (puppet standing height), `bg_dim 0.2–0.6`, `bg_blur 0–6`, `tint` (pull puppets toward the picture's cold light).

## 8. Fallback policy
`engine/sets.py` keeps one dark fallback set `horror` (abandoned corridor) used only when a picture file is missing at render time. Never design shots around it; if a picture cannot be generated, list the missing key for the user, keep the build moving, and regenerate the image before final delivery.
