"""Broadcast frame (horror-channel identity), drawn after the grade in the screen pass:
navy paw-print strips, fiction-disclaimer banner, channel badge, hard subtitles synced to the
voiceover sentences, and a small watermark.

Config: the optional "frame" block in story.json (every field optional; horror defaults are ON):
  "frame": {
    "on": true,
    "channel": "TÊN KÊNH CỦA ANH",
    "badge": true,
    "disclaimer": "NỘI DUNG VIDEO CHỈ LÀ HƯ CẤU KHÔNG CÓ THẬT — KHÔNG BẮT CHƯỚC HAY LÀM THEO!",
    "captions": true,
    "watermark": true,
    "paws": true
  }
Set "on": false, or a layer to false / "", to switch it off. The badge and watermark use the
channel name the creator owns; never copy another channel's name or logo.
"""
import random
import skia
from .kit import *

TOP_H = 46          # navy strip at the very top
BOT_Y = 1032        # navy strip at the very bottom
DEFAULT_CHANNEL = "KÊNH KINH DỊ"
DEFAULT_DISCLAIMER = "NỘI DUNG VIDEO CHỈ LÀ HƯ CẤU KHÔNG CÓ THẬT · KHÔNG BẮT CHƯỚC HAY LÀM THEO!"
NAVY = '#141B33'
NAVY_DARK = '#0D1326'


def paw(c, x, y, s, col=NAVY_DARK, alpha=255):
    """A simple paw print: one pad plus four toes."""
    c.save(); c.translate(x, y); c.scale(s, s)
    c.drawOval(skia.Rect(-16, 2, 16, 26), fp(col, alpha))
    for (dx, dy, r) in ((-22, -14, 9), (-8, -24, 10), (8, -24, 10), (22, -14, 9)):
        c.drawCircle(dx, dy, r, fp(col, alpha))
    c.restore()


def stripes(c):
    """Top and bottom navy strips with scattered paw prints plus three small record dots."""
    c.drawRect(skia.Rect(-60, -60, W + 60, TOP_H), fp(NAVY))
    c.drawRect(skia.Rect(-60, BOT_Y, W + 60, H + 60), fp(NAVY))
    rnd = random.Random(21)
    for k in range(15):
        paw(c, 90 + k * 124 + rnd.uniform(-22, 22), 24 + rnd.uniform(-6, 6), .85, alpha=210)
        paw(c, 60 + k * 128 + rnd.uniform(-22, 22), BOT_Y + 26 + rnd.uniform(-5, 5), .85, alpha=210)
    for x, col in ((64, '#7A2030'), (108, '#2E4A86'), (152, '#1F5E58')):
        c.drawCircle(x, 23, 13, fp(col, 230)); c.drawCircle(x, 23, 13, ink(3, '#0A0E1C', 200))


def disclaimer(c, text):
    """Top-left fiction warning: red bar + two lines of uppercase white hand lettering."""
    if not text: return
    lines = wrap(text.upper(), 30, 1180, KALAM)[:2]
    y = 82
    rect(c, 56, y - 34, 70, y + 8 + (len(lines) - 1) * 38, '#C8242C', 0)
    for i, ln in enumerate(lines):
        label(c, ln, 86, y + i * 38, 30, CREAM, font=KALAM, stroke=7, stroke_col='#0A0E1C', skew=-0.1)


def badge(c, channel):
    """Top-right channel badge: red accent mark + marker lettering."""
    if not channel: return
    name = channel.upper()
    size = 54
    w = text_w(name, size, MARKER)
    x, y = W - 64, 92
    c.save(); c.translate(x, y)
    c.drawPath(skia.Path.Polygon([(-w - 46, -26), (-w - 22, -44), (-w, -26), (-w - 22, -8)], True), fp('#C8242C', 235))
    label(c, name, 0, 0, size, CREAM, font=MARKER, align='right', stroke=6, stroke_col='#0A0E1C', skew=0)
    c.restore()


def caption_text(tl, t, shot):
    """The spoken sentence currently playing, in output-clock time; None on silent/title cards."""
    if tl is None or getattr(shot, "card", False): return None
    for s in tl.shots:
        if s.get("silent") or not s.get("sents"): continue
        for i in s["sents"]:
            a, b = tl.sent_span(i)
            if a - .15 <= t < b - .04:
                return tl.S[i].get("text")
    return None


def captions(c, text):
    """Hard subtitle: translucent black band, one or two uppercase white lines, near the bottom."""
    if not text: return
    up = text.upper()
    lines = wrap(up, 44, 1560, KALAM)[:2]
    size = 44 if len(lines) == 1 else 36
    lines = wrap(up, size, 1560, KALAM)[:2]
    widths = [text_w(ln, size, KALAM) for ln in lines]
    bw = max(widths) + 96
    bh = len(lines) * (size * 1.12) + 30
    y1 = BOT_Y - 14
    y0 = y1 - bh
    c.drawRRect(skia.RRect.MakeRectXY(skia.Rect(W / 2 - bw / 2, y0, W / 2 + bw / 2, y1), 18, 18), fp((8, 9, 16), 205))
    for i, ln in enumerate(lines):
        label(c, ln, W / 2, y0 + 34 + i * size * 1.12, size, '#FFFFFF', font=KALAM,
              align='center', stroke=5, stroke_col='#0A0E1C', skew=0)


def watermark(c, channel):
    if not channel: return
    label(c, "YTB: " + channel.upper(), W - 56, BOT_Y + 28, 24, CREAM, font=KALAM,
          align='right', skew=0, alpha=.55)


def draw_overlay(c, t, shot):
    story = getattr(getattr(shot, "env", None), "story", None) or {}
    cfg = story.get("frame") or {}
    if cfg.get("on", True) is False: return
    if cfg.get("paws", True): stripes(c)
    if cfg.get("badge", True): badge(c, cfg.get("channel", DEFAULT_CHANNEL))
    if cfg.get("disclaimer", True): disclaimer(c, cfg.get("disclaimer", DEFAULT_DISCLAIMER))
    if cfg.get("watermark", True): watermark(c, cfg.get("channel", DEFAULT_CHANNEL))
    if cfg.get("captions", True):
        txt = caption_text(getattr(getattr(shot, "env", None), "tl", None), t, shot)
        captions(c, txt)
