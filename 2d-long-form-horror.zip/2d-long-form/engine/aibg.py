"""AI backgrounds: story.json "backgrounds" -> P/bg/<key>.jpg (1920x1080), used by shots with "bg": "<key>".

story.json:
  "bg_style": "...the look of THIS video, chosen for its niche/topic (see references/backgrounds.md; horror default)...",
  "backgrounds": {
     "tro_hall_night": {"prompt": "narrow old guesthouse corridor at night, weak greenish bulbs, numbered doors, thin fog on the tiles", "time": "night",
                      "floor": 1010, "seed": 12, "tint": "#9FB0D8"},
     ...
  }
  shot: {"kind": "wide", "bg": "tro_hall_night", ...}   (a dark "horror" drawn set stays the fallback only if the image is missing)
  An inline dict also works: "bg": {"prompt": "...", "time": "day"} (key = auto_<hash>).

The agent running the skill writes the prompts and the style for each video's niche and topic, and normally makes
the pictures itself with its own image tool (python3 -m engine bgs <P> --todo lists what is missing).
Sources, in order (python3 -m engine bgs <P> [--provider auto|cloudflare|pollinations|gemini|openai|free|manual]):
  1. files already in P/bg/ (images the agent made with its own image tool, or the user's uploads)
  2. Cloudflare Workers AI  CF_ACCOUNT_ID + CF_API_TOKEN       (free daily allowance; model CF_IMAGE_MODEL)
  3. Pollinations           POLLINATIONS_KEY                   (gen.pollinations.ai; model POLLINATIONS_MODEL)
  4. Google Gemini          GEMINI_API_KEY                     (model GEMINI_IMAGE_MODEL)
  5. OpenAI                 OPENAI_API_KEY                     (model OPENAI_IMAGE_MODEL)
  6. free                   anonymous image.pollinations.ai    (no key: 1 image per ~45 s, lower quality, may carry a watermark)
Every image is normalized to a 1920x1080 JPEG (cover crop). Missing images fall back to the drawn set.
"""
import base64, hashlib, json, os, re, sys, time, urllib.error, urllib.parse, urllib.request, zipfile

W, H = 1920, 1080
EXTS = (".jpg", ".jpeg", ".png", ".webp")
# The look is the agent's choice per niche ("bg_style"); this fallback is the horror-channel default.
DEFAULT_STYLE = ("dark atmospheric 2D painted horror background illustration for a mystery animation channel, rough ink outlines, "
                 "cold desaturated navy-blue and grey palette, thin fog, film grain and scratches, dim sickly light sources, "
                 "melancholy dread mood, hand-painted brush texture, no cel-shaded cheerful colours")
# Always appended, whatever the style: the engine adds the characters and the text itself.
RULES = ("2D illustrated background plate, wide 16:9 shot at eye level, clear empty floor space across the lower third, "
         "uncluttered centre, no people, no characters, no faces, no animals, no text, no letters, no signs with writing, "
         "no logos, no watermark, no photographs, no 3D render look")
TIME_HINT = dict(night="deep night, cold blue moonlight through fog, long black shadows, one faint warm lantern or candle glow, oppressive darkness",
                 dusk="gloomy blue-violet overcast dusk, dead grey light, no warm sunset, thin mist low on the ground",
                 day="pale grey overcast daylight, sickly desaturated blue tones, haze, no direct sunlight, claustrophobic quiet")


# ---------------------------------------------------------------- story -> background list
def _slug(s): return re.sub(r"[^a-z0-9_]+", "_", s.lower()).strip("_")


def bg_key(spec_bg):
    if isinstance(spec_bg, dict): return "auto_" + hashlib.md5(json.dumps(spec_bg, sort_keys=True).encode()).hexdigest()[:8]
    return str(spec_bg)


def collect(story):
    """All backgrounds the story defines or uses: key -> def (with 'full' prompt). Unknown keys -> def None."""
    defs = {k: dict(v) for k, v in (story.get("backgrounds") or {}).items()}
    used = []
    for sh in story.get("shots", []):
        b = sh.get("bg")
        if not b or (isinstance(b, str) and b.startswith("#")): continue  # "#hex" = a plain colour (title cards)
        k = bg_key(b)
        if isinstance(b, dict): defs.setdefault(k, dict(b))
        elif k not in defs: defs.setdefault(k, None)
        if k not in used: used.append(k)
    style = story.get("bg_style") or DEFAULT_STYLE
    for k, d in defs.items():
        if d is None: continue
        hint = TIME_HINT.get(d.get("time", ""), "")
        d["full"] = ", ".join(x for x in (d.get("prompt", k.replace("_", " ")), hint, d.get("style") or style, RULES) if x)
        d.setdefault("seed", int(hashlib.md5(k.encode()).hexdigest()[:6], 16) % 100000)
    return defs, used


def find_file(P, key, d=None):
    if d and d.get("file"):
        f = d["file"] if os.path.isabs(d["file"]) else os.path.join(P, d["file"])
        return f if os.path.exists(f) else None
    for e in EXTS:
        f = os.path.join(P, "bg", key + e)
        if os.path.exists(f): return f
    return None


def resolve(P, story, spec_bg):
    """For shots: (key, def, path-or-None)."""
    if not spec_bg or (isinstance(spec_bg, str) and spec_bg.startswith("#")): return None, None, None
    defs, _ = collect(story); k = bg_key(spec_bg); d = defs.get(k)
    if d is None and isinstance(spec_bg, str):  # a direct file path also works: "bg": "bg/my_room.png"
        f = spec_bg if os.path.isabs(spec_bg) else os.path.join(P, spec_bg)
        if os.path.exists(f): return k, {}, f
    return k, d or {}, find_file(P, k, d)


# ---------------------------------------------------------------- image helpers (skia only, no extra deps)
def normalize(data, out):
    """Any image bytes -> 1920x1080 JPEG (cover crop, centred). Returns (w, h) of the source."""
    import skia
    img = skia.Image.MakeFromEncoded(skia.Data.MakeWithCopy(data))
    if img is None: raise ValueError("not an image (the service probably returned an error page)")
    sw, sh = img.width(), img.height(); s = max(W / sw, H / sh); dw, dh = sw * s, sh * s
    surf = skia.Surface(W, H); c = surf.getCanvas(); c.clear(skia.ColorBLACK)
    c.drawImageRect(img, skia.Rect((W - dw) / 2, (H - dh) / 2, (W + dw) / 2, (H + dh) / 2), skia.SamplingOptions(skia.CubicResampler.Mitchell()))
    os.makedirs(os.path.dirname(out), exist_ok=True)
    tmp = out + ".tmp"; surf.makeImageSnapshot().save(tmp, skia.kJPEG, 92); os.replace(tmp, out)
    return sw, sh


def _http(url, data=None, headers=None, timeout=180):
    h = {"User-Agent": "2d-long-form/1.0"}; h.update(headers or {})
    if isinstance(data, (dict, list)): data = json.dumps(data).encode(); h.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=data, headers=h, method="POST" if data is not None else "GET")
    with urllib.request.urlopen(req, timeout=timeout) as r: return r.read(), r.headers.get("Content-Type", "")


def _env(*names):
    for n in names:
        if os.environ.get(n): return os.environ[n]
    return None


# ---------------------------------------------------------------- providers: prompt -> image bytes
def gen_cloudflare(prompt, seed):
    acc, tok = _env("CF_ACCOUNT_ID", "CLOUDFLARE_ACCOUNT_ID"), _env("CF_API_TOKEN", "CLOUDFLARE_API_TOKEN")
    model = _env("CF_IMAGE_MODEL") or "@cf/black-forest-labs/flux-1-schnell"
    body = {"prompt": prompt[:2000], "seed": seed}
    if "flux-1-schnell" in model: body["steps"] = 8      # square 1024 output; cover-cropped to 16:9
    else: body.update(width=1920, height=1088)          # SDXL / lucid-origin / phoenix take a size
    raw, ct = _http(f"https://api.cloudflare.com/client/v4/accounts/{acc}/ai/run/{model}", body, {"Authorization": f"Bearer {tok}"})
    if ct.startswith("image/"): return raw
    j = json.loads(raw); r = j.get("result") or {}
    if not r.get("image"): raise RuntimeError(f"cloudflare: {str(j.get('errors') or j)[:300]}")
    return base64.b64decode(r["image"])


def gen_pollinations(prompt, seed):
    key = _env("POLLINATIONS_KEY", "POLLINATIONS_API_KEY"); model = _env("POLLINATIONS_MODEL") or "flux"
    q = urllib.parse.quote(prompt[:1800], safe="")
    url = f"https://gen.pollinations.ai/image/{q}?width=1920&height=1080&seed={seed}&model={model}&nologo=true&enhance=false"
    raw, ct = _http(url, headers={"Authorization": f"Bearer {key}"}); return raw


def gen_gemini(prompt, seed):
    key = _env("GEMINI_API_KEY", "GOOGLE_API_KEY"); model = _env("GEMINI_IMAGE_MODEL") or "gemini-2.5-flash-image"
    body = {"contents": [{"parts": [{"text": "Generate one image, no text in the image: " + prompt}]}],
            "generationConfig": {"responseModalities": ["IMAGE"], "imageConfig": {"aspectRatio": "16:9"}}}
    raw, _ = _http(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent", body, {"x-goog-api-key": key})
    j = json.loads(raw)
    for cand in j.get("candidates", []):
        for p in cand.get("content", {}).get("parts", []):
            d = p.get("inlineData") or p.get("inline_data")
            if d and d.get("data"): return base64.b64decode(d["data"])
    raise RuntimeError(f"gemini: no image in reply: {str(j)[:300]}")


def gen_openai(prompt, seed):
    key = _env("OPENAI_API_KEY"); model = _env("OPENAI_IMAGE_MODEL") or "gpt-image-1"
    body = {"model": model, "prompt": prompt[:3900], "size": "1536x1024", "n": 1, "quality": _env("OPENAI_IMAGE_QUALITY") or "medium"}
    raw, _ = _http("https://api.openai.com/v1/images/generations", body, {"Authorization": f"Bearer {key}"})
    d = json.loads(raw)["data"][0]
    return base64.b64decode(d["b64_json"]) if d.get("b64_json") else _http(d["url"])[0]


def gen_free(prompt, seed):
    q = urllib.parse.quote(prompt[:1500], safe="")
    raw, ct = _http(f"https://image.pollinations.ai/prompt/{q}?width=1920&height=1080&seed={seed}&nologo=true", timeout=120); return raw


PROVIDERS = dict(cloudflare=(gen_cloudflare, lambda: _env("CF_ACCOUNT_ID", "CLOUDFLARE_ACCOUNT_ID") and _env("CF_API_TOKEN", "CLOUDFLARE_API_TOKEN"), 0),
                 pollinations=(gen_pollinations, lambda: _env("POLLINATIONS_KEY", "POLLINATIONS_API_KEY"), 0),
                 gemini=(gen_gemini, lambda: _env("GEMINI_API_KEY", "GOOGLE_API_KEY"), 0),
                 openai=(gen_openai, lambda: _env("OPENAI_API_KEY"), 0),
                 free=(gen_free, lambda: True, 47))  # (function, configured?, seconds between calls)


def chain(provider):
    if provider == "manual": return []
    if provider != "auto":
        if provider not in PROVIDERS: raise SystemExit(f"unknown provider {provider}: use auto, {', '.join(PROVIDERS)} or manual")
        return [provider]
    return [p for p, (_, ok, _) in PROVIDERS.items() if ok()]


# ---------------------------------------------------------------- the bgs command
def write_prompts(P, defs, used):
    os.makedirs(os.path.join(P, "bg"), exist_ok=True); keys = [k for k in defs if defs[k] is not None]
    with open(os.path.join(P, "bg", "PROMPTS.md"), "w", encoding="utf-8") as fh:
        fh.write("# AI background prompts\n\nMake each image 16:9 (any size, 1920x1080 is ideal). Save it as `bg/<key>.jpg` "
                 "(or .png/.webp), or name it by its number (`01.png`, `02.png`, ...) and import the folder/zip with "
                 "`python3 -m engine bgs <P> --import <folder-or-zip>`.\n\n")
        for i, k in enumerate(keys, 1):
            fh.write(f"## {i:02d} · {k}{'' if k in used else '  (defined, not used by any shot)'}\n\n```\n{defs[k]['full']}\n```\n\n")
    json.dump({k: defs[k]["full"] for k in keys}, open(os.path.join(P, "bg", "prompts.json"), "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    return keys


def import_images(P, src, keys):
    """Copy user images (folder or zip) into P/bg by key name or by number (01, 2, ...)."""
    files = []
    if zipfile.is_zipfile(src):
        z = zipfile.ZipFile(src)
        files = [(os.path.basename(n), z.read(n)) for n in z.namelist() if n.lower().endswith(EXTS) and not n.startswith("__MACOSX")]
    elif os.path.isdir(src):
        for n in sorted(os.listdir(src)):
            if n.lower().endswith(EXTS): files.append((n, open(os.path.join(src, n), "rb").read()))
    elif os.path.isfile(src): files = [(os.path.basename(src), open(src, "rb").read())]
    norm = {_slug(k): k for k in keys}; n_ok = 0
    for name, data in files:
        stem = _slug(os.path.splitext(name)[0]); key = norm.get(stem)
        if key is None:
            m = re.match(r"^0*(\d+)", stem)
            if m and 1 <= int(m.group(1)) <= len(keys): key = keys[int(m.group(1)) - 1]
        if key is None: print(f"  skip {name}: no background key matches (keys: {', '.join(keys)})"); continue
        try:
            sw, sh = normalize(data, os.path.join(P, "bg", key + ".jpg")); _clean(P, key); n_ok += 1
            print(f"  {name} -> bg/{key}.jpg ({sw}x{sh}{', not 16:9: cropped' if abs(sw / sh - 16 / 9) > .05 else ''})")
        except Exception as e: print(f"  skip {name}: {e}")
    print(f"imported {n_ok} image(s)")


def _clean(P, key):  # keep only bg/<key>.jpg
    for e in EXTS:
        f = os.path.join(P, "bg", key + e)
        if e != ".jpg" and os.path.exists(f): os.remove(f)


def ensure_normalized(P, key):
    f = find_file(P, key)
    if not f: return None
    out = os.path.join(P, "bg", key + ".jpg")
    import skia
    img = skia.Image.MakeFromEncoded(skia.Data.MakeWithCopy(open(f, "rb").read()))
    if img is None: print(f"  bg/{os.path.basename(f)} is not a readable image: delete or replace it"); return None
    if f == out and (img.width(), img.height()) == (W, H): return out
    normalize(open(f, "rb").read(), out); _clean(P, key); print(f"  normalized {os.path.basename(f)} -> bg/{key}.jpg"); return out


def todo_list(P):
    """For the agent's own image tool: the pictures still missing, with the full prompt and the file to save."""
    story = json.load(open(os.path.join(P, "story.json"), encoding="utf-8")); defs, used = collect(story); write_prompts(P, defs, used)
    out = [dict(key=k, save_as=os.path.join(P, "bg", k + ".png"), prompt=d["full"]) for k, d in defs.items() if d is not None and not find_file(P, k, d)]
    print(json.dumps(out, indent=1, ensure_ascii=False))
    print(f"\n{len(out)} picture(s) to make. Save each one (16:9) at save_as, then run: python3 -m engine bgs {P} --provider manual", file=sys.stderr)


def run(P, provider="auto", force=None, only=None, src=None):
    story = json.load(open(os.path.join(P, "story.json"), encoding="utf-8")); defs, used = collect(story)
    for k in used:
        if defs.get(k) is None: print(f"WARNING: shots use background '{k}' but story.json 'backgrounds' has no prompt for it")
    keys = write_prompts(P, defs, used)
    if not keys: print("story.json has no backgrounds (add a \"backgrounds\" block and \"bg\" on shots)"); return
    if src: import_images(P, src, keys)
    todo = [k for k in keys if (only is None or k in only)]
    force = set(keys if force == ["all"] else force or [])
    for k in force:
        for e in EXTS:
            f = os.path.join(P, "bg", k + e)
            if os.path.exists(f) and not src: os.remove(f)
    have = {k for k in todo if ensure_normalized(P, k)}
    missing = [k for k in todo if k not in have and not defs[k].get("file")]
    provs = chain(provider); last = {}
    if missing and not provs:
        print("no image service configured (or --provider manual): make the images from bg/PROMPTS.md and import them")
    for i, k in enumerate(missing):
        d = defs[k]; seed = d["seed"] if k not in force else int(time.time() * 1000) % 100000
        for p in provs:
            fn, _, gap = PROVIDERS[p]; wait = gap - (time.time() - last.get(p, 0))
            if wait > 0: time.sleep(wait)
            t0 = time.time()
            for attempt in range(4):
                try:
                    data = fn(d["full"], seed); last[p] = time.time()
                    sw, sh = normalize(data, os.path.join(P, "bg", k + ".jpg")); have.add(k)
                    print(f"[{i + 1}/{len(missing)}] {k}: {p} {sw}x{sh} ({time.time() - t0:.0f}s)" + ("  (free tier: may carry a small watermark)" if p == "free" else ""), flush=True)
                    break
                except urllib.error.HTTPError as e:
                    last[p] = time.time(); msg = e.read()[:200].decode("utf-8", "ignore")
                    print(f"  {k}: {p} HTTP {e.code} {msg}", flush=True)
                    m = re.search(r"[Rr]etry after (\d+)", msg)
                    if e.code in (402, 429, 503) and attempt < 3 and (m or e.code != 402):
                        time.sleep(min(90, int(m.group(1)) + 2 if m else (gap or 10))); continue
                    break
                except Exception as e:
                    last[p] = time.time(); print(f"  {k}: {p} failed: {str(e)[:200]}", flush=True); break
            if k in have: break
    left = [k for k in todo if k not in have]
    print(f"\nbackgrounds: {len(have)}/{len(todo)} ready in {os.path.join(P, 'bg')}")
    if left: print("missing (shots fall back to their drawn 'set'):", ", ".join(left), "\nprompts for them: bg/PROMPTS.md")
    if have: sheet(P, [k for k in keys if k in have])


def sheet(P, keys, out_name="bg_sheet.jpg"):
    import skia
    from .kit import KALAM, fp, C
    tw, th, cols = 480, 270, 4; rows = -(-len(keys) // cols)
    surf = skia.Surface(cols * tw, rows * (th + 34)); c = surf.getCanvas(); c.clear(C((20, 20, 26)))
    for j, k in enumerate(keys):
        img = skia.Image.MakeFromEncoded(skia.Data.MakeWithCopy(open(find_file(P, k), "rb").read())); x, y = (j % cols) * tw, (j // cols) * (th + 34)
        c.drawImageRect(img, skia.Rect(x + 2, y + 2, x + tw - 2, y + th - 2), skia.SamplingOptions(skia.FilterMode.kLinear))
        c.drawString(f"{j + 1:02d} {k}", x + 8, y + th + 26, skia.Font(KALAM, 22), fp('#FFFFFF'))
    os.makedirs(os.path.join(P, "work"), exist_ok=True); pth = os.path.join(P, "work", out_name)
    surf.makeImageSnapshot().save(pth, skia.kJPEG, 90); print("sheet ->", pth); return pth


def stamp(P, story, spec_bg):
    """Cache key part for a shot's background file (re-render when the image changes)."""
    k, d, f = resolve(P, story, spec_bg)
    if not f: return None
    st = os.stat(f); return [os.path.basename(f), st.st_size, int(st.st_mtime)]
