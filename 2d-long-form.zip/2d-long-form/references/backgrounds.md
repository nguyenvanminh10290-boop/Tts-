# AI backgrounds: designing the visual world of each video

No video ships with ready-made pictures. **You (the agent running this skill) design and make the backgrounds for every video yourself**, fitted to its niche, topic, era and places. A money video, a 1920s con-man story, a horror tale and a psychology explainer should each look like their own world. The engine only draws the puppets, the graphics and the motion over your pictures.

## Workflow

1. **Read the script** and list every place × era × time of day the story visits (e.g. "Paris street, 1925, night", "hotel suite, 1925, day", "prison cell, 1935, night").
2. **Pick the look** for the whole video from the niche table below and write it as `bg_style` (one line, in English). Adapt it to the topic: change the palette, era and texture so it fits *this* story, not just the niche.
3. **Write one `backgrounds` entry per place** (see "Writing prompts"), plus a close variant for places that hold many shots, plus 2-4 soft backdrops for graphics shots that fit the topic.
4. **Make the pictures with your own image-generation tool:** run `python3 -m engine bgs <P> --todo`. It prints each missing picture's key, its full prompt (your prompt plus the time hint, your `bg_style` and the fixed rules) and the `save_as` path. Generate each one in 16:9 (landscape) and save it at that path. Several independent images can be generated in parallel.
5. Run `python3 -m engine bgs <P> --provider manual`: it normalizes every picture to 1920x1080 and builds `work/bg_sheet.jpg`.
6. **Look at the sheet.** Regenerate any picture with people, readable text, a watermark, a style that doesn't match the others, or no open floor in the lower third. Delete the bad file and make it again.
7. Show the sheet to the user in one line (Vietnamese) and keep going without waiting.

**If you have no image tool:** run `python3 -m engine bgs <P>` (auto). It uses any configured key (`CF_ACCOUNT_ID` + `CF_API_TOKEN`, `POLLINATIONS_KEY`, `GEMINI_API_KEY`, `OPENAI_API_KEY`), otherwise the free anonymous Pollinations route (slow: about 1 picture per 45 s; lower quality; small watermark). If nothing works, tell the user in one line: they can make the pictures from `bg/PROMPTS.md` in any image app and upload them (`bgs <P> --import <zip|folder>`, files named by key or `01.png`, `02.png`...), or the video uses the built-in drawn sets. Never stop the build over missing pictures: those shots fall back to their `set`.

## Picking the look per niche

The style must stay **2D illustrated** (painted or flat), because the puppets are flat ink cartoons; photoreal or 3D pictures make them look pasted on. Inside that limit, change everything else. Starting points (adapt them; don't copy them word for word for every video):

| niche / topic | `bg_style` starting point | palette and light | typical places |
|---|---|---|---|
| money, personal finance, investing | clean flat 2D vector illustration, bold ink outlines, crisp geometric shapes, soft grain | teal, navy, warm gold accents; clean daylight or calm evening | modern apartment, bank lobby, office, supermarket, city street, kitchen table with bills |
| business, startups, brand stories | bold flat editorial illustration, thick outlines, graphic shadows | saturated brand-free colours, high contrast | garage workshop, boardroom, factory floor, shop front, skyscraper exterior |
| psychology, self-improvement, life lessons | soft painted 2D storybook illustration, gentle ink lines, light watercolor texture | pastels, warm cream, soft pink and sky blue; soft morning light | bedroom, café, park bench, classroom, quiet street, dreamlike abstract room |
| history, true stories, biographies | vintage 2D illustration, ink linework, aged paper texture, slightly faded print colours | sepia, ochre, muted red; era-correct light (gas lamps, candles) | era-correct streets, palaces, ports, offices, battlefields far away, newspaper rooms |
| scams, true crime, con artists, heists | noir 2D comic illustration, heavy ink shadows, halftone texture | deep navy and black with warm lamp pools, a single red accent | rainy streets, smoky offices, hotel lobbies, casinos, police stations, courtrooms |
| mystery, horror, unexplained | dark atmospheric 2D painted illustration, rough ink, fog and grain | cold blue-green, desaturated, a sickly yellow light source | abandoned houses, forests at night, hospital corridors, villages, basements |
| science, space, technology, future | clean sci-fi 2D illustration, smooth gradients, thin ink outlines, glowing accents | deep indigo, cyan and magenta glow | labs, control rooms, space stations, server rooms, futuristic cities |
| health, body, food | friendly flat 2D illustration, rounded shapes, bright clean colours | fresh greens, white, coral | kitchen, gym, clinic, market stall, bedroom at night |
| geography, countries, economics, travel | detailed 2D travel-poster illustration, ink outlines, flat colour blocks | local colours of the place; strong sunlight or dusk | the real city/landscape of the story (skylines, markets, ports, rice fields, deserts) |
| fables, kids stories, moral tales | warm hand-painted 2D picture-book illustration, soft ink lines, gouache texture | warm and bright | village, forest, castle, school, farm |
| motivation, success stories | cinematic 2D illustration, dramatic light, bold outlines | golden hour, long shadows | rooftops, stadiums, empty roads, small rented rooms, stages |

Rules for the look:
- **One `bg_style` for the whole video**, so the pictures match. Use a per-background `style` only for a deliberate change: a sepia flashback, a dream, a "future" scene.
- Match the music: `mood` (mystery, upbeat, dramatic, calm, tense) and the picture style should tell the same story.
- **Places follow the story, not the market.** A story set in Hanoi gets Hanoi streets even for the English market. A generic "you" scene gets a setting the market audience knows: an American suburb or apartment for `en`; a Vietnamese apartment (chung cư), a sidewalk café, a street with motorbikes, an old-quarter tube house or a market for `vi`; a Parisian or French town flat for `fr`; a German city flat, an Altbau stairwell or a Bäckerei street for `de`.
- For real places and eras, check what they looked like (web search) when it matters: architecture, vehicles, clothing on posters, technology.

## Writing prompts

- **English, 1-2 sentences:** place + era + 3-5 concrete props + light. Example: `"a cramped 1920s Paris hotel room, iron bed, flowered wallpaper, a leather suitcase on a chair, tall window with lace curtains"`.
- Put the **important props at the sides or the back**, keep the centre and the lower third open (puppets stand there; the engine appends this rule, but compose for it too).
- Never ask for people, characters, crowds, animals, brands, logos, readable text, or a named artist, studio, film or channel style.
- `time`: `night`, `dusk` or `day` adds a lighting hint and sets the shot's mood.
- After generating, set `floor` (feet line, default 1010) where the floor really is, and `char_s` (0.7-0.85) for big rooms and streets.

How many pictures: 3 min ≈ 6-10, 5 min ≈ 10-14, 10 min ≈ 16-24, 15 min ≈ 22-32. Count about one picture per 4-6 shots, change the picture whenever the place or time changes, and alternate a wide and a close version of places you stay in.

**Backdrops for graphics** (icon, counter, list, versus, chapter cards) should echo the topic: coins and a ledger on a desk (money), an old map and a compass on parchment (history), a rainy window with an evidence board (crime), a soft abstract room with floating shapes (psychology), a starfield (space). They are blurred and washed by the engine, so keep them simple.
